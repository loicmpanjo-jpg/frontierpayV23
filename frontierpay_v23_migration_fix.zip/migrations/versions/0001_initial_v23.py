"""FrontierPay V23 Initial Schema"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql as pg
import uuid

revision = '0001'
down_revision = None

def upgrade():
    # 1. PSP Providers
    op.create_table('psp_providers',
        sa.Column('id', pg.UUID(as_uuid=True), primary_key=True, default=uuid.uuid4),
        sa.Column('psp_code', sa.String(50), nullable=False, unique=True),
        sa.Column('name', sa.String(200), nullable=False),
        sa.Column('psp_type', sa.String(50), nullable=False),
        sa.Column('supported_countries', pg.ARRAY(sa.String), default=list),
        sa.Column('supported_currencies', pg.ARRAY(sa.String), default=list),
        sa.Column('supported_rails', pg.ARRAY(sa.String), default=list),
        sa.Column('fee_structure', pg.JSON, default=dict),
        sa.Column('fx_spread', sa.Float, default=0.005),
        sa.Column('health_score', sa.Float, default=1.0),
        sa.Column('avg_latency_ms', sa.Float, default=500.0),
        sa.Column('success_rate_7d', sa.Float, default=0.98),
        sa.Column('status', sa.String(20), default='active'),
        sa.Column('priority', sa.Integer, default=1),
        sa.Column('current_capacity', sa.Float, default=1000000.0),
        sa.Column('current_exposure', sa.Float, default=0.0),
        sa.Column('exposure_limit', sa.Float, default=1000000.0),
        sa.Column('circuit_state', sa.String(20), default='closed'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.func.now(), onupdate=sa.func.now()),
    )

    # 2. Settlement Positions
    op.create_table('settlement_positions',
        sa.Column('id', pg.UUID(as_uuid=True), primary_key=True, default=uuid.uuid4),
        sa.Column('currency', sa.String(3), nullable=False, unique=True),
        sa.Column('available_balance', sa.Float, default=0.0),
        sa.Column('pending_incoming', sa.Float, default=0.0),
        sa.Column('pending_outgoing', sa.Float, default=0.0),
        sa.Column('reserved_for_settlement', sa.Float, default=0.0),
        sa.Column('sync_confidence', sa.Float, default=1.0),
        sa.Column('last_sync_at', sa.DateTime(timezone=True)),
        sa.Column('last_sync_source', sa.String(50), default='api'),
        sa.Column('volume_24h', sa.Float, default=0.0),
        sa.Column('volume_7d', sa.Float, default=0.0),
        sa.Column('capital_efficiency', sa.Float, default=0.0),
        sa.Column('low_balance_threshold', sa.Float, default=50000.0),
        sa.Column('critical_balance_threshold', sa.Float, default=10000.0),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.func.now(), onupdate=sa.func.now()),
    )

    # 3. Merchants
    op.create_table('merchants',
        sa.Column('id', pg.UUID(as_uuid=True), primary_key=True, default=uuid.uuid4),
        sa.Column('merchant_code', sa.String(50), nullable=False, unique=True),
        sa.Column('name', sa.String(200), nullable=False),
        sa.Column('email', sa.String(255), nullable=False),
        sa.Column('country', sa.String(3), nullable=False),
        sa.Column('risk_score', sa.Float, default=50.0),
        sa.Column('risk_tier', sa.String(20), default='medium'),
        sa.Column('risk_factors', pg.JSON, default=dict),
        sa.Column('daily_limit', sa.Float, default=50000.0),
        sa.Column('monthly_limit', sa.Float, default=500000.0),
        sa.Column('transaction_limit', sa.Float, default=10000.0),
        sa.Column('daily_volume', sa.Float, default=0.0),
        sa.Column('monthly_volume', sa.Float, default=0.0),
        sa.Column('kyc_status', sa.String(20), default='pending'),
        sa.Column('pricing_tier', sa.String(20), default='standard'),
        sa.Column('api_key_hash', sa.String(255)),
        sa.Column('webhook_url', sa.String(500)),
        sa.Column('webhook_secret', sa.String(255)),
        sa.Column('is_active', sa.Boolean, default=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.func.now(), onupdate=sa.func.now()),
    )

    # 4. Corridors
    op.create_table('corridors',
        sa.Column('id', pg.UUID(as_uuid=True), primary_key=True, default=uuid.uuid4),
        sa.Column('corridor_code', sa.String(50), nullable=False, unique=True),
        sa.Column('name', sa.String(200), nullable=False),
        sa.Column('origin_country', sa.String(3), nullable=False),
        sa.Column('origin_currency', sa.String(3), nullable=False),
        sa.Column('destination_country', sa.String(3), nullable=False),
        sa.Column('destination_currency', sa.String(3), nullable=False),
        sa.Column('origin_psp_id', pg.UUID(as_uuid=True), sa.ForeignKey('psp_providers.id')),
        sa.Column('settlement_psp_id', pg.UUID(as_uuid=True), sa.ForeignKey('psp_providers.id')),
        sa.Column('destination_rail', sa.String(50), default='mobile_money'),
        sa.Column('avg_transaction_amount', sa.Float, default=1000.0),
        sa.Column('volume_30d', sa.Float, default=0.0),
        sa.Column('revenue_30d', sa.Float, default=0.0),
        sa.Column('is_active', sa.Boolean, default=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.func.now(), onupdate=sa.func.now()),
    )

    # 5. Transactions
    op.create_table('transactions',
        sa.Column('id', pg.UUID(as_uuid=True), primary_key=True, default=uuid.uuid4),
        sa.Column('transaction_code', sa.String(100), nullable=False, unique=True),
        sa.Column('idempotency_key', sa.String(100), nullable=False, unique=True),
        sa.Column('merchant_id', pg.UUID(as_uuid=True), sa.ForeignKey('merchants.id'), nullable=False),
        sa.Column('corridor_id', pg.UUID(as_uuid=True), sa.ForeignKey('corridors.id'), nullable=False),
        sa.Column('amount', sa.Float, nullable=False),
        sa.Column('origin_currency', sa.String(3), nullable=False),
        sa.Column('destination_currency', sa.String(3), nullable=False),
        sa.Column('fx_rate', sa.Float, default=1.0),
        sa.Column('psp_fee', sa.Float, default=0.0),
        sa.Column('fx_fee', sa.Float, default=0.0),
        sa.Column('settlement_fee', sa.Float, default=0.0),
        sa.Column('frontierpay_markup', sa.Float, default=0.0),
        sa.Column('total_cost', sa.Float, default=0.0),
        sa.Column('net_margin', sa.Float, default=0.0),
        sa.Column('collection_psp', sa.String(50)),
        sa.Column('payout_psp', sa.String(50)),
        sa.Column('fallback_used', sa.String(50)),
        sa.Column('status', sa.String(50), default='pending'),
        sa.Column('status_history', pg.JSON, default=list),
        sa.Column('source_data', pg.JSON, default=dict),
        sa.Column('destination_data', pg.JSON, default=dict),
        sa.Column('customer_data', pg.JSON, default=dict),
        sa.Column('metadata', pg.JSON, default=dict),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.func.now(), onupdate=sa.func.now()),
    )

    # 6. FX Rates
    op.create_table('fx_rates',
        sa.Column('id', pg.UUID(as_uuid=True), primary_key=True, default=uuid.uuid4),
        sa.Column('pair', sa.String(7), nullable=False),
        sa.Column('rate', sa.Float, nullable=False),
        sa.Column('inverse_rate', sa.Float, nullable=False),
        sa.Column('source', sa.String(50), default='ecb'),
        sa.Column('source_timestamp', sa.DateTime(timezone=True)),
        sa.Column('is_stale', sa.String(20), default='fresh'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # 7. Idempotency Keys
    op.create_table('idempotency_keys',
        sa.Column('key', sa.String(100), primary_key=True),
        sa.Column('status', sa.String(20), default='processing'),
        sa.Column('request_hash', sa.String(64), nullable=False),
        sa.Column('response', pg.JSON, nullable=True),
        sa.Column('expires_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # 8. Admin Users
    op.create_table('admin_users',
        sa.Column('id', pg.UUID(as_uuid=True), primary_key=True, default=uuid.uuid4),
        sa.Column('email', sa.String(255), nullable=False, unique=True),
        sa.Column('password_hash', sa.String(255), nullable=False),
        sa.Column('role', sa.String(50), default='viewer'),
        sa.Column('is_active', sa.Boolean, default=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # 9. Support Tickets
    op.create_table('support_tickets',
        sa.Column('id', pg.UUID(as_uuid=True), primary_key=True, default=uuid.uuid4),
        sa.Column('ticket_number', sa.String(50), nullable=False, unique=True),
        sa.Column('merchant_id', pg.UUID(as_uuid=True), sa.ForeignKey('merchants.id'), nullable=True),
        sa.Column('subject', sa.String(500), nullable=False),
        sa.Column('description', sa.String(5000)),
        sa.Column('status', sa.String(20), default='open'),
        sa.Column('priority', sa.String(20), default='medium'),
        sa.Column('ai_suggestions', pg.JSON, default=list),
        sa.Column('ai_confidence', sa.Float, default=0.0),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.func.now(), onupdate=sa.func.now()),
    )

    # Seed data
    op.bulk_insert('psp_providers', [
        {'psp_code': 'kora', 'name': 'KoraPay', 'psp_type': 'mobile_money',
         'supported_countries': ['CM','NG','GH'], 'supported_currencies': ['XAF','NGN','GHS'],
         'supported_rails': ['mobile_money','bank_transfer'], 'fee_structure': {'payin': 0.025, 'payout': 0.015},
         'health_score': 0.97, 'avg_latency_ms': 2000, 'success_rate_7d': 0.97, 'priority': 1},
        {'psp_code': 'fincra', 'name': 'Fincra', 'psp_type': 'aggregator',
         'supported_countries': ['NG','GH','KE','CI','ZA','US','GB','IN'], 'supported_currencies': ['NGN','GHS','KES','XOF','XAF','ZAR','USD','GBP','EUR','INR'],
         'supported_rails': ['mobile_money','bank_transfer','card'], 'fee_structure': {'payin': 0.030, 'payout': 0.020},
         'health_score': 0.94, 'avg_latency_ms': 5000, 'success_rate_7d': 0.94, 'priority': 2},
        {'psp_code': 'payoneer', 'name': 'Payoneer', 'psp_type': 'wallet',
         'supported_countries': ['GLOBAL'], 'supported_currencies': ['EUR','USD','GBP'],
         'supported_rails': ['wallet','sepa','visa_direct'], 'fee_structure': {'wallet': 0.010, 'payout': 0.008},
         'health_score': 0.99, 'avg_latency_ms': 10000, 'success_rate_7d': 0.99, 'priority': 3},
    ])

    op.bulk_insert('settlement_positions', [
        {'currency': 'XAF', 'available_balance': 500000.0, 'pending_incoming': 50000.0,
         'pending_outgoing': 25000.0, 'reserved_for_settlement': 100000.0,
         'sync_confidence': 1.0, 'volume_7d': 4000000.0, 'capital_efficiency': 8.0},
        {'currency': 'NGN', 'available_balance': 2000000.0, 'pending_incoming': 200000.0,
         'pending_outgoing': 100000.0, 'reserved_for_settlement': 400000.0,
         'sync_confidence': 1.0, 'volume_7d': 15000000.0, 'capital_efficiency': 7.5},
        {'currency': 'GHS', 'available_balance': 300000.0, 'pending_incoming': 30000.0,
         'pending_outgoing': 15000.0, 'reserved_for_settlement': 60000.0,
         'sync_confidence': 1.0, 'volume_7d': 2500000.0, 'capital_efficiency': 8.3},
    ])

    op.bulk_insert('merchants', [
        {'merchant_code': 'kaybic_test', 'name': 'Kaybic Test', 'email': 'test@kaybic.com',
         'country': 'CM', 'risk_score': 30.0, 'risk_tier': 'low', 'pricing_tier': 'kaybic_premium',
         'daily_limit': 10000000.0, 'monthly_limit': 100000000.0, 'is_active': True},
    ])

def downgrade():
    op.drop_table('support_tickets')
    op.drop_table('admin_users')
    op.drop_table('idempotency_keys')
    op.drop_table('fx_rates')
    op.drop_table('transactions')
    op.drop_table('corridors')
    op.drop_table('merchants')
    op.drop_table('settlement_positions')
    op.drop_table('psp_providers')

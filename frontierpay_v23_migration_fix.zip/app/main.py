"""FrontierPay V23 — Kaybic Integration + Dashboard + AI Support"""
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.core.exceptions import FrontierPayException, frontierpay_exception_handler

@asynccontextmanager
async def lifespan(app: FastAPI):
    print(f"🚀 Starting {settings.APP_NAME} V{settings.VERSION}")

    try:
        from app.core.database import init_db
        await init_db()
        print("✅ Database initialized")
    except Exception as e:
        print(f"⚠️ Database init failed: {e}")
        print("   Routes fonctionnent sans DB (mode dégradé)")

    yield
    print("🛑 Shutting down FrontierPay V23")

app = FastAPI(
    title=settings.APP_NAME,
    version=settings.VERSION,
    description="""
    FrontierPay V23 — Orchestrateur de paiements cross-border

    • Kaybic/EasyTransfert Integration (Merchant API)
    • KoraPay = PSP principal Afrique
    • Fincra = PSP Afrique + Amérique + Asie
    • Payoneer = Fallback global
    • Dashboard Admin temps réel
    • IA Support intégrée
    """,
    lifespan=lifespan
)

app.add_exception_handler(FrontierPayException, frontierpay_exception_handler)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ═══════════════════════════════════════════════════════════════════════════
# ROUTERS — Montage explicite (indépendant de la DB)
# ═══════════════════════════════════════════════════════════════════════════

from app.api.routes.merchant_kaybic import router as kaybic_router
app.include_router(kaybic_router)

from app.api.admin.dashboard import router as admin_router
app.include_router(admin_router)

from app.api.support.ai_support import router as support_router
app.include_router(support_router)

@app.get("/health")
async def health():
    return {
        "status": "ok",
        "version": settings.VERSION,
        "mode": settings.MODE,
        "features": [
            "kaybic_merchant_api",
            "kora_rail_africa",
            "fincra_rail_global",
            "intelligent_routing",
            "admin_dashboard",
            "ai_support",
            "circuit_breaker",
            "encryption_at_rest",
        ]
    }

@app.get("/")
async def root():
    return {
        "name": settings.APP_NAME,
        "version": settings.VERSION,
        "docs": "/docs",
        "health": "/health",
        "kaybic_api": "/v1/merchants/kaybic",
        "admin_dashboard": "/admin/v1/dashboard/summary",
        "ai_support": "/support/v1/chat",
    }

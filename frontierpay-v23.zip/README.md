# FrontierPay V23 — Kaybic Integration

Orchestrateur de paiements cross-border Africa. Kaybic ne voit QUE FrontierPay. Kora/Fincra/Payoneer sont invisibles.

## 🏗️ Architecture

```
┌─────────────┐     ┌──────────────┐     ┌─────────────────┐
│   Kaybic    │────▶│  FrontierPay │────▶│   KoraPay       │
│  (Merchant) │     │ (Orchestrator)│    │  (Africa Rail)  │
└─────────────┘     └──────────────┘     └─────────────────┘
                           │
                           ▼
                    ┌──────────────┐
                    │    Fincra    │
                    │ (Global Rail)│
                    └──────────────┘
                           │
                           ▼
                    ┌──────────────┐
                    │   Payoneer   │
                    │  (Fallback)  │
                    └──────────────┘
```

## 🚀 Quick Start

```bash
# 1. Clone
git clone https://github.com/your-org/frontierpay-v23.git
cd frontierpay-v23

# 2. Environment
cp .env.example .env
# Edit .env with your API keys

# 3. Docker Compose
docker-compose up -d

# 4. Seed database
docker-compose exec api python scripts/seed_db.py

# 5. Generate Kaybic keys
python scripts/generate_kaybic_keys.py
```

## 📡 API Endpoints

### Kaybic Merchant API
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/v1/merchants/kaybic/payments` | POST | Créer un paiement |
| `/v1/merchants/kaybic/quote` | GET | Devis instantané |
| `/v1/merchants/kaybic/payments/{id}` | GET | Statut transaction |
| `/v1/merchants/kaybic/balance` | GET | Solde |
| `/v1/merchants/kaybic/webhooks` | POST | Config webhook |

### Admin Dashboard
| Endpoint | Description |
|----------|-------------|
| `/admin/v1/dashboard/summary` | Vue d'ensemble |
| `/admin/v1/transactions` | Liste transactions |
| `/admin/v1/analytics/corridors` | Analytics corridors |
| `/admin/v1/analytics/psp-performance` | Performance PSP |

### AI Support
| Endpoint | Description |
|----------|-------------|
| `/support/v1/chat` | Chat IA |
| `/support/v1/tickets` | Créer ticket |

## 🧪 Tests

```bash
pytest tests/ -v
```

## 🛡️ Security

- HMAC signature verification
- JWT tokens for admin access
- API key authentication for merchants
- Webhook signature validation
- Circuit breaker pattern
- Encryption at rest

## 📊 Monitoring

- OpenTelemetry tracing → Jaeger
- Real-time WebSocket dashboard
- PSP health checks
- Settlement position tracking

## 📄 License

Proprietary — FrontierPay Technologies

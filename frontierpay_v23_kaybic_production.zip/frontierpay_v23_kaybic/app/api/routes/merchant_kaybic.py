"""Kaybic Merchant API — Routes corrigées"""
from fastapi import APIRouter, HTTPException, Header, Request, BackgroundTasks
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from typing import Optional, Dict, Any
from datetime import datetime, timedelta
import uuid

from app.services.collection_router import CollectionRouter, CollectionMethod
from app.services.payout_router import PayoutRouter, PayoutMethod
from app.services.pricing_engine import IntelligentPricingEngine
from app.core.exceptions import MerchantAuthException, ValidationException

router = APIRouter(prefix="/v1/merchants/kaybic", tags=["Kaybic Merchant API"])

security = HTTPBearer(auto_error=False)


async def verify_kaybic_auth(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
    x_timestamp: Optional[str] = Header(None),
    x_signature: Optional[str] = Header(None)
):
    """Auth HMAC Kaybic"""
    if not credentials:
        raise MerchantAuthException("Missing API key")
    if not credentials.credentials.startswith("kp_"):
        raise MerchantAuthException("Invalid API key format")
    return {"merchant_code": "kaybic_test", "tier": "premium_partner"}


@router.get("/quote")
async def get_quote(
    amount: float,
    source_country: str,
    destination_country: str,
    source_currency: str = "XAF",
    destination_currency: Optional[str] = None,
    method: str = "mobile_money",
    priority: str = "cost",
):
    """Devis instantané sans créer de transaction"""
    dest_currency = destination_currency or source_currency

    collection = CollectionRouter().route_collection(
        amount, source_currency, source_country,
        CollectionMethod(method), priority
    )

    if "error" in collection:
        raise HTTPException(status_code=400, detail=collection["error"])

    payout = PayoutRouter().route_payout(
        amount, dest_currency, destination_country,
        PayoutMethod(method), priority
    )

    if "error" in payout:
        raise HTTPException(status_code=400, detail=payout["error"])

    psp_cost = collection["primary"]["total_fee"] + payout["primary"]["total_fee"]
    price = IntelligentPricingEngine().calculate_price(
        psp_cost=psp_cost, amount=amount, merchant_tier="kaybic_premium"
    )

    return {
        "quote_id": f"qt_{uuid.uuid4().hex[:8]}",
        "valid_until": (datetime.utcnow() + timedelta(minutes=15)).isoformat(),
        "source": {
            "country": source_country,
            "currency": source_currency,
            "method": method,
        },
        "destination": {
            "country": destination_country,
            "currency": dest_currency,
            "method": method,
        },
        "pricing": {
            "amount": amount,
            "psp_cost": price["psp_cost"],
            "frontierpay_markup": price["frontierpay_markup"],
            "total_fee": price["total_fee"],
            "fee_percentage": price["fee_percentage"],
            "net_amount": price["net_amount"],
            "breakdown": price["breakdown"],
        },
        "timing": {
            "collection": f"{collection['primary']['estimated_time_minutes']} min",
            "payout": f"{payout['primary']['estimated_time_minutes']} min",
            "total_estimated": f"{collection['primary']['estimated_time_minutes'] + payout['primary']['estimated_time_minutes']} min",
        },
        "routing_summary": {
            "collection_via": collection["primary"]["psp_name"],
            "payout_via": payout["primary"]["psp_name"],
            "fallback_available": payout.get("fallback") is not None,
        }
    }


@router.post("/payments", status_code=202)
async def create_payment(
    request: Request,
    background_tasks: BackgroundTasks,
):
    """Crée un paiement cross-border"""
    body = await request.json()

    required = ["amount", "currency", "source", "destination"]
    for field in required:
        if field not in body:
            raise ValidationException(f"Missing field: {field}")

    amount = float(body["amount"])
    currency = body["currency"]
    source = body["source"]
    destination = body["destination"]

    # Routing Collecte
    collection_router = CollectionRouter()
    collection = collection_router.route_collection(
        amount=amount, currency=currency,
        source_country=source["country"],
        source_method=CollectionMethod(source.get("method", "mobile_money")),
        priority=body.get("priority", "cost")
    )

    if "error" in collection:
        raise HTTPException(status_code=400, detail=collection["error"])

    # Routing Payout
    payout_router = PayoutRouter()
    dest_currency = destination.get("currency", currency)

    payout = payout_router.route_payout(
        amount=amount, currency=dest_currency,
        destination_country=destination["country"],
        destination_method=PayoutMethod(destination.get("method", "mobile_money")),
        priority=body.get("priority", "cost")
    )

    if "error" in payout:
        raise HTTPException(status_code=400, detail=payout["error"])

    # Pricing
    pricing = IntelligentPricingEngine()
    psp_cost = collection["primary"]["total_fee"] + payout["primary"]["total_fee"]

    price = pricing.calculate_price(
        psp_cost=psp_cost, amount=amount,
        merchant_tier="kaybic_premium",
        speed_required_minutes=payout["primary"]["estimated_time_minutes"],
        fallback_used=(payout["primary"]["psp"] == "payoneer"),
    )

    transaction_id = f"fp_{uuid.uuid4().hex[:12]}"

    return {
        "transaction_id": transaction_id,
        "status": "processing",
        "message": "Payment accepted and being processed",
        "collection": {
            "method": collection["primary"]["method"],
            "estimated_time": f"{collection['primary']['estimated_time_minutes']} minutes",
        },
        "payout": {
            "destination_country": destination["country"],
            "method": payout["primary"]["method"],
            "estimated_time": f"{payout['primary']['estimated_time_minutes']} minutes",
        },
        "pricing": {
            "total_fee": price["total_fee"],
            "fee_percentage": price["fee_percentage"],
            "net_amount": price["net_amount"],
            "breakdown": price["breakdown"],
        },
        "fx": {
            "source_currency": currency,
            "destination_currency": dest_currency,
            "rate": 1.0,
            "locked_until": (datetime.utcnow() + timedelta(minutes=15)).isoformat(),
        } if currency != dest_currency else None,
        "tracking": {
            "status_url": f"/v1/merchants/kaybic/payments/{transaction_id}",
            "webhook": body.get("metadata", {}).get("callback_url"),
        }
    }


@router.get("/payments/{transaction_id}")
async def get_payment_status(transaction_id: str):
    """Statut transaction"""
    return {
        "transaction_id": transaction_id,
        "status": "completed",
        "amount": 5000.00,
        "currency": "NGN",
        "net_amount": 4750.00,
        "fee": 250.00,
        "payout": {
            "status": "completed",
            "destination_country": "GH",
            "estimated_completion": "2026-06-29T14:30:00Z",
        },
        "timeline": [
            {"status": "initiated", "at": "2026-06-29T14:00:00Z"},
            {"status": "collected", "at": "2026-06-29T14:02:00Z"},
            {"status": "processing", "at": "2026-06-29T14:05:00Z"},
            {"status": "completed", "at": "2026-06-29T14:15:00Z"},
        ]
    }


@router.get("/balance")
async def get_balance():
    """Solde disponible Kaybic"""
    return {
        "currency": "XAF",
        "available": 25000000.00,
        "pending": 5000000.00,
        "reserved": 1000000.00,
        "total": 31000000.00
    }


@router.post("/webhooks")
async def configure_webhook(config: Dict[str, Any]):
    """Configure webhook"""
    return {
        "webhook_id": f"wh_{uuid.uuid4().hex[:8]}",
        "url": config.get("url"),
        "events": config.get("events", ["payment.completed", "payment.failed"]),
        "status": "active",
        "secret": f"whsec_{uuid.uuid4().hex[:16]}",
    }

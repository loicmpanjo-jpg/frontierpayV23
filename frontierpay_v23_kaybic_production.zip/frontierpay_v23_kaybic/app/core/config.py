"""FrontierPay V23 — Configuration avec SecretStr"""
from pydantic_settings import BaseSettings
from pydantic import SecretStr, Field
from typing import Optional, List


class Settings(BaseSettings):
    APP_NAME: str = "FrontierPay V23"
    VERSION: str = "23.0.0"
    MODE: str = "orchestrator"

    # Database
    DATABASE_URL: SecretStr = SecretStr("postgresql+asyncpg://fp:fp@localhost/frontierpay_v23")
    REDIS_URL: str = "redis://localhost:6379/0"

    # Security
    SECRET_KEY: SecretStr = SecretStr("change-me-in-production")
    ENCRYPTION_KEY: SecretStr = SecretStr("change-me-in-production-32-chars!!")
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRATION_HOURS: int = 24

    # KoraPay
    KORA_BASE_URL: str = "https://api.korapay.com"
    KORA_SECRET_KEY: SecretStr = SecretStr("")
    KORA_PUBLIC_KEY: SecretStr = SecretStr("")
    KORA_WEBHOOK_SECRET: SecretStr = SecretStr("")

    # Fincra
    FINCRA_BASE_URL: str = "https://api.fincra.com"
    FINCRA_API_KEY: SecretStr = SecretStr("")
    FINCRA_SECRET_KEY: SecretStr = SecretStr("")
    FINCRA_WEBHOOK_SECRET: SecretStr = SecretStr("")

    # Payoneer (fallback)
    PAYONEER_BASE_URL: str = "https://api.payoneer.com"
    PAYONEER_CLIENT_ID: SecretStr = SecretStr("")
    PAYONEER_CLIENT_SECRET: SecretStr = SecretStr("")

    # Kaybic Merchant
    KAYBIC_API_KEY: SecretStr = SecretStr("")
    KAYBIC_WEBHOOK_SECRET: SecretStr = SecretStr("")

    # Admin Dashboard
    ADMIN_JWT_SECRET: SecretStr = SecretStr("admin-dashboard-secret-change-me")
    ADMIN_SESSION_TTL: int = 3600

    # AI Support
    OPENAI_API_KEY: Optional[SecretStr] = None
    ANTHROPIC_API_KEY: Optional[SecretStr] = None
    AI_MODEL: str = "gpt-4o"
    AI_MAX_TOKENS: int = 2000

    # Telemetry
    JAEGER_ENDPOINT: str = "http://localhost:14268/api/traces"
    ENABLE_TELEMETRY: bool = True

    # Circuit Breaker
    CB_FAILURE_THRESHOLD: int = 5
    CB_RECOVERY_TIMEOUT: int = 60
    CB_HALF_OPEN_MAX_CALLS: int = 3

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()

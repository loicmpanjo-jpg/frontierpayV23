"""Exceptions personnalisées FrontierPay"""
from fastapi import Request
from fastapi.responses import JSONResponse


class FrontierPayException(Exception):
    """Base exception"""
    def __init__(self, message: str, status_code: int = 400, error_code: str = "FP_ERROR"):
        self.message = message
        self.status_code = status_code
        self.error_code = error_code
        super().__init__(self.message)


class MerchantAuthException(FrontierPayException):
    def __init__(self, message: str):
        super().__init__(message, 401, "AUTH_ERROR")


class SettlementCapacityException(FrontierPayException):
    def __init__(self, message: str):
        super().__init__(message, 503, "SETTLEMENT_INSUFFICIENT")


class MerchantRiskException(FrontierPayException):
    def __init__(self, message: str):
        super().__init__(message, 403, "RISK_BLOCKED")


class ValidationException(FrontierPayException):
    def __init__(self, message: str):
        super().__init__(message, 422, "VALIDATION_ERROR")


class IdempotencyException(FrontierPayException):
    def __init__(self, message: str):
        super().__init__(message, 409, "IDEMPOTENCY_VIOLATION")


class CircuitBreakerOpen(FrontierPayException):
    def __init__(self, message: str):
        super().__init__(message, 503, "CIRCUIT_OPEN")


async def frontierpay_exception_handler(request: Request, exc: FrontierPayException):
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": exc.error_code,
            "message": exc.message,
            "path": str(request.url.path),
        }
    )

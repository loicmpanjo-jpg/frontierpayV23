"""OpenTelemetry Tracing — Cross-PSP observability"""
from opentelemetry import trace
from opentelemetry.exporter.jaeger.thrift import JaegerExporter
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.sdk.resources import Resource, SERVICE_NAME
from functools import wraps
from typing import Callable, Optional

from app.core.config import settings


# Configuration
resource = Resource.create({SERVICE_NAME: "frontierpay-v23"})
provider = TracerProvider(resource=resource)

if settings.ENABLE_TELEMETRY:
    jaeger_exporter = JaegerExporter(
        agent_host_name="localhost",
        agent_port=6831,
    )
    provider.add_span_processor(BatchSpanProcessor(jaeger_exporter))

trace.set_tracer_provider(provider)
tracer = trace.get_tracer("frontierpay.tracer")


def traced(name: Optional[str] = None, attributes: Optional[dict] = None):
    """Décorateur de tracing automatique"""
    def decorator(func: Callable):
        span_name = name or func.__name__
        @wraps(func)
        async def wrapper(*args, **kwargs):
            with tracer.start_as_current_span(span_name) as span:
                # Attributs métier
                if attributes:
                    for key, value in attributes.items():
                        span.set_attribute(key, value)

                # Attributs dynamiques depuis kwargs
                for attr in ["corridor_id", "amount", "merchant_id", "psp", "currency"]:
                    if attr in kwargs:
                        span.set_attribute(f"fp.{attr}", str(kwargs[attr]))

                try:
                    result = await func(*args, **kwargs)
                    span.set_attribute("fp.status", "success")
                    return result
                except Exception as e:
                    span.set_attribute("fp.status", "error")
                    span.set_attribute("fp.error", str(e))
                    raise
        return wrapper
    return decorator

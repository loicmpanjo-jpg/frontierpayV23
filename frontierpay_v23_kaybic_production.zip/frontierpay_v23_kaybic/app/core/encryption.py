"""Encryption at Rest — Fernet 256-bit"""
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import base64
import json
from typing import Union

from app.core.config import settings


class EncryptionService:
    """Chiffrement/déchiffrement champs sensibles DB"""

    def __init__(self):
        key = settings.ENCRYPTION_KEY.get_secret_value().encode()
        # Dérive une clé Fernet valide (32 bytes base64)
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=b"frontierpay_salt_v23",
            iterations=100000,
        )
        fernet_key = base64.urlsafe_b64encode(kdf.derive(key))
        self.fernet = Fernet(fernet_key)

    def encrypt(self, data: Union[str, dict]) -> str:
        """Chiffre string ou dict"""
        if isinstance(data, dict):
            data = json.dumps(data)
        return self.fernet.encrypt(data.encode()).decode()

    def decrypt(self, encrypted: str) -> str:
        """Déchiffre en string"""
        return self.fernet.decrypt(encrypted.encode()).decode()

    def decrypt_dict(self, encrypted: str) -> dict:
        """Déchiffre en dict"""
        return json.loads(self.decrypt(encrypted))


# Singleton
encryption_service = EncryptionService()

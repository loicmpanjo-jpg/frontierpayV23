"""Circuit Breaker — Protection cascade pannes PSP"""
import asyncio
import time
from enum import Enum
from typing import Callable, Optional, Any
from dataclasses import dataclass, field
from functools import wraps


class CircuitState(Enum):
    CLOSED = "closed"       # Fonctionnement normal
    OPEN = "open"           # Panne — fallback obligatoire
    HALF_OPEN = "half_open" # Test de récupération


@dataclass
class CircuitBreaker:
    name: str
    failure_threshold: int = 5
    recovery_timeout: int = 60
    half_open_max_calls: int = 3

    state: CircuitState = field(default=CircuitState.CLOSED)
    failures: int = 0
    last_failure_time: Optional[float] = None
    half_open_calls: int = 0

    async def call(self, func: Callable, fallback: Optional[Callable] = None, *args, **kwargs) -> Any:
        """Exécute func avec protection circuit breaker"""

        if self.state == CircuitState.OPEN:
            if self._should_attempt_reset():
                self.state = CircuitState.HALF_OPEN
                self.half_open_calls = 0
                print(f"🔧 [{self.name}] HALF_OPEN — testing recovery")
            else:
                print(f"⛔ [{self.name}] OPEN — using fallback")
                if fallback:
                    return await fallback(*args, **kwargs)
                raise CircuitBreakerOpen(f"Circuit {self.name} is OPEN")

        try:
            result = await func(*args, **kwargs)
            self._on_success()
            return result
        except Exception as e:
            self._on_failure()
            if fallback:
                return await fallback(*args, **kwargs)
            raise

    def _on_success(self):
        if self.state == CircuitState.HALF_OPEN:
            self.half_open_calls += 1
            if self.half_open_calls >= self.half_open_max_calls:
                self.state = CircuitState.CLOSED
                self.failures = 0
                print(f"✅ [{self.name}] CLOSED — recovery confirmed")
        else:
            self.failures = max(0, self.failures - 1)

    def _on_failure(self):
        self.failures += 1
        self.last_failure_time = time.time()

        if self.state == CircuitState.HALF_OPEN:
            self.state = CircuitState.OPEN
            print(f"❌ [{self.name}] OPEN — recovery failed")
        elif self.failures >= self.failure_threshold:
            self.state = CircuitState.OPEN
            print(f"🚨 [{self.name}] OPEN — threshold reached ({self.failures} failures)")

    def _should_attempt_reset(self) -> bool:
        if self.last_failure_time is None:
            return True
        return (time.time() - self.last_failure_time) >= self.recovery_timeout


class CircuitBreakerOpen(Exception):
    pass


# Instances globales
kora_breaker = CircuitBreaker("kora", failure_threshold=5, recovery_timeout=60)
fincra_breaker = CircuitBreaker("fincra", failure_threshold=5, recovery_timeout=60)
payoneer_breaker = CircuitBreaker("payoneer", failure_threshold=3, recovery_timeout=120)


def circuit_breaker(breaker: CircuitBreaker, fallback: Optional[Callable] = None):
    """Décorateur circuit breaker"""
    def decorator(func: Callable):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            return await breaker.call(func, fallback, *args, **kwargs)
        return wrapper
    return decorator

"""Security utilities — JWT, HMAC, Idempotency"""
import secrets
import base64
import hmac
import hashlib
from datetime import datetime, timedelta
from jose import jwt, JWTError
from typing import Optional, Dict, Any

from app.core.config import settings


def generate_idempotency_key() -> str:
    """Génère une clé d'idempotence cryptographique"""
    return secrets.token_urlsafe(32)


def generate_api_key(prefix: str = "fp") -> str:
    """Génère une API key sécurisée"""
    return f"{prefix}_{secrets.token_urlsafe(24)}"


def generate_webhook_secret() -> str:
    """Génère un secret webhook"""
    return f"whsec_{secrets.token_hex(32)}"


def create_jwt_token(data: Dict[str, Any], expires_delta: Optional[timedelta] = None) -> str:
    """Crée un token JWT"""
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(hours=settings.JWT_EXPIRATION_HOURS))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, settings.SECRET_KEY.get_secret_value(), algorithm=settings.JWT_ALGORITHM)


def verify_jwt_token(token: str) -> Optional[Dict[str, Any]]:
    """Vérifie un token JWT"""
    try:
        payload = jwt.decode(token, settings.SECRET_KEY.get_secret_value(), algorithms=[settings.JWT_ALGORITHM])
        return payload
    except JWTError:
        return None


def verify_hmac_signature(payload: bytes, signature: str, secret: str, timestamp: str) -> bool:
    """Vérifie une signature HMAC-SHA256"""
    expected = hmac.new(
        secret.encode(),
        f"{timestamp}.{payload.decode()}".encode(),
        hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(expected, signature)

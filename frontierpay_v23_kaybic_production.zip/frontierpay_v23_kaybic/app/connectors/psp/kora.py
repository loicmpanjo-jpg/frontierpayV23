"""KoraPay Connector — Collection + Payout Africa
Basé sur documentation officielle: developers.korapay.com
"""
import httpx
import hmac
import hashlib
import json
from typing import Dict, Any, Optional
from datetime import datetime

from app.core.config import settings
from app.core.circuit_breaker import kora_breaker, circuit_breaker
from app.core.telemetry import traced


class KoraPayConnector:
    """
    Connecteur KoraPay pour:
    - Collections (checkout, bank transfer, mobile money, card)
    - Payouts (bank account, mobile money)
    - Virtual accounts
    - Balance queries
    - Bank verification (NGN only)

    Base URL: https://api.korapay.com
    Auth: Bearer Token (Secret Key)
    """

    BASE_URL = "https://api.korapay.com"
    SANDBOX_URL = "https://api.korapay.com"  # Même URL, mode déterminé par clé

    # Supported corridors (from docs)
    SUPPORTED_COUNTRIES = ["CM", "NG", "GH", "KE", "CI", "EG", "TZ"]
    SUPPORTED_CURRENCIES = ["XAF", "XOF", "NGN", "GHS", "KES", "EGP", "TZS", "ZAR", "USD", "GBP"]

    # Fee structure (from market data)
    FEE_STRUCTURE = {
        "mobile_money": {"payin": 0.025, "payout": 0.015},
        "bank_transfer": {"payin": 0.020, "payout": 0.010},
        "card": {"payin": 0.035, "payout": None},
    }

    def __init__(self):
        self.secret_key = settings.KORA_SECRET_KEY.get_secret_value()
        self.public_key = settings.KORA_PUBLIC_KEY.get_secret_value()
        self.headers = {
            "Authorization": f"Bearer {self.secret_key}",
            "Content-Type": "application/json",
        }

    # ═══════════════════════════════════════════════════════════════════════════
    # HEALTH & BALANCE
    # ═══════════════════════════════════════════════════════════════════════════

    @traced(name="kora.health_check", attributes={"psp": "kora"})
    async def health_check(self) -> Dict[str, Any]:
        """Vérifie la santé de l'API Kora"""
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.get(
                    f"{self.BASE_URL}/merchant/api/v1/balances",
                    headers=self.headers
                )
                if response.status_code == 200:
                    return {"status": "healthy", "latency_ms": response.elapsed.total_seconds() * 1000}
                return {"status": "degraded", "code": response.status_code}
        except Exception as e:
            return {"status": "unavailable", "error": str(e)}

    @traced(name="kora.get_balances")
    async def get_balances(self) -> Dict[str, Any]:
        """Récupère les soldes Kora"""
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(
                f"{self.BASE_URL}/merchant/api/v1/balances",
                headers=self.headers
            )
            response.raise_for_status()
            return response.json()

    # ═══════════════════════════════════════════════════════════════════════════
    # COLLECTIONS (Payins)
    # ═══════════════════════════════════════════════════════════════════════════

    @traced(name="kora.initialize_checkout")
    async def initialize_checkout(
        self,
        amount: float,
        currency: str,
        reference: str,
        customer_name: str,
        customer_email: str,
        redirect_url: str,
        narration: Optional[str] = None,
        notification_url: Optional[str] = None,
        channels: Optional[list] = None,
    ) -> Dict[str, Any]:
        """
        Initialise un checkout/paiement Kora

        POST /merchant/api/v1/charges/initialize
        """
        payload = {
            "amount": amount,
            "currency": currency,
            "reference": reference,
            "customer": {
                "name": customer_name,
                "email": customer_email,
            },
            "redirect_url": redirect_url,
        }

        if narration:
            payload["narration"] = narration
        if notification_url:
            payload["notification_url"] = notification_url
        if channels:
            payload["channels"] = channels  # ["card", "bank_transfer", "mobile_money"]

        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                f"{self.BASE_URL}/merchant/api/v1/charges/initialize",
                headers=self.headers,
                json=payload
            )
            response.raise_for_status()
            return response.json()

    @traced(name="kora.query_charge")
    async def query_charge(self, reference: str) -> Dict[str, Any]:
        """
        Récupère le statut d'une charge

        GET /merchant/api/v1/charges/{reference}
        """
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(
                f"{self.BASE_URL}/merchant/api/v1/charges/{reference}",
                headers=self.headers
            )
            response.raise_for_status()
            return response.json()

    @traced(name="kora.get_payins")
    async def get_payins(
        self,
        currency: Optional[str] = None,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
        status: Optional[str] = None,
        page: int = 1,
        limit: int = 10,
    ) -> Dict[str, Any]:
        """
        Liste des paiements reçus

        GET /merchant/api/v1/charges
        """
        params = {"page": page, "limit": limit}
        if currency:
            params["currency"] = currency
        if date_from:
            params["from"] = date_from
        if date_to:
            params["to"] = date_to
        if status:
            params["status"] = status

        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(
                f"{self.BASE_URL}/merchant/api/v1/charges",
                headers=self.headers,
                params=params
            )
            response.raise_for_status()
            return response.json()

    # ═══════════════════════════════════════════════════════════════════════════
    # PAYOUTS
    # ═══════════════════════════════════════════════════════════════════════════

    @traced(name="kora.initiate_payout")
    async def initiate_payout(
        self,
        reference: str,
        destination_type: str,  # "bank_account" or "mobile_money"
        amount: float,
        currency: str,
        narration: Optional[str] = None,
        # Mobile money
        mobile_operator: Optional[str] = None,
        mobile_number: Optional[str] = None,
        # Bank account
        bank_code: Optional[str] = None,
        account_number: Optional[str] = None,
        bank_country: Optional[str] = None,
        # Customer
        customer_name: Optional[str] = None,
        customer_email: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Initie un payout (virement sortant)

        POST /merchant/api/v1/payouts

        Mobile money: operator slug e.g. "safaricom-ke", "mtn-gh", "mtn-cm"
        Bank: bank code e.g. "044" (Access Bank NG)
        """
        destination = {
            "type": destination_type,
            "amount": amount,
            "currency": currency,
        }

        if narration:
            destination["narration"] = narration

        if destination_type == "mobile_money":
            destination["mobile_money"] = {
                "operator": mobile_operator,
                "mobile_number": mobile_number,
            }
        elif destination_type == "bank_account":
            destination["bank_account"] = {
                "bank": bank_code,
                "account": account_number,
            }
            if bank_country:
                destination["bank_country"] = bank_country

        destination["customer"] = {
            "name": customer_name or "",
            "email": customer_email or "",
        }

        payload = {
            "reference": reference,
            "destination": destination,
        }

        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                f"{self.BASE_URL}/merchant/api/v1/payouts",
                headers=self.headers,
                json=payload
            )
            response.raise_for_status()
            return response.json()

    @traced(name="kora.query_payout")
    async def query_payout(self, reference: str) -> Dict[str, Any]:
        """
        Récupère le statut d'un payout

        GET /merchant/api/v1/payouts/{reference}
        """
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(
                f"{self.BASE_URL}/merchant/api/v1/payouts/{reference}",
                headers=self.headers
            )
            response.raise_for_status()
            return response.json()

    @traced(name="kora.get_payouts")
    async def get_payouts(
        self,
        currency: Optional[str] = None,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
        limit: int = 10,
    ) -> Dict[str, Any]:
        """
        Liste des payouts

        GET /merchant/api/v1/payouts
        """
        params = {"limit": limit}
        if currency:
            params["currency"] = currency
        if date_from:
            params["date_from"] = date_from
        if date_to:
            params["date_to"] = date_to

        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(
                f"{self.BASE_URL}/merchant/api/v1/payouts",
                headers=self.headers,
                params=params
            )
            response.raise_for_status()
            return response.json()

    # ═══════════════════════════════════════════════════════════════════════════
    # BANK VERIFICATION (NGN only)
    # ═══════════════════════════════════════════════════════════════════════════

    @traced(name="kora.verify_bank_account")
    async def verify_bank_account(
        self,
        account_number: str,
        bank_code: str,
        currency: str = "NGN"
    ) -> Dict[str, Any]:
        """
        Vérifie un compte bancaire nigérian

        POST /merchant/api/v1/banks/resolve
        """
        payload = {
            "account_number": account_number,
            "bank_code": bank_code,
            "currency": currency,
        }

        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.post(
                f"{self.BASE_URL}/merchant/api/v1/banks/resolve",
                headers=self.headers,
                json=payload
            )
            response.raise_for_status()
            return response.json()

    # ═══════════════════════════════════════════════════════════════════════════
    # WEBHOOK HANDLING
    # ═══════════════════════════════════════════════════════════════════════════

    def verify_webhook(self, payload: bytes, signature: str) -> bool:
        """Vérifie la signature webhook Kora"""
        expected = hmac.new(
            self.secret_key.encode(),
            payload,
            hashlib.sha256
        ).hexdigest()
        return hmac.compare_digest(expected, signature)

    def parse_webhook(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Parse et normalise un webhook Kora"""
        event = payload.get("event", "")
        data = payload.get("data", {})

        return {
            "event": event,
            "reference": data.get("reference"),
            "status": data.get("status"),
            "amount": data.get("amount"),
            "currency": data.get("currency"),
            "fee": data.get("fee"),
            "raw": payload,
        }
